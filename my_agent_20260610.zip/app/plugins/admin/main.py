from flask import Blueprint

bp = Blueprint("admin", __name__, template_folder='templates', url_prefix="/admin")

blueprint_name = "admin"